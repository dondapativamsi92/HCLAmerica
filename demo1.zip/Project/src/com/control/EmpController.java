package com.control;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;  
import org.springframework.web.bind.annotation.RequestMapping;  
import org.springframework.web.bind.annotation.RequestMethod;  
import org.springframework.web.servlet.ModelAndView;

import com.bean.CardBean;
import com.bean.CloudBean;
import com.bean.EmpBean;
import com.bean.EmpDetailsBean;
import com.bean.EmployeeBean;
import com.bean.PaymentBean;
import com.bean.UserBean;
import com.dao.Dao;

@Controller  
public class EmpController {
	@Autowired  
    Dao dao;
	
	@RequestMapping("/empform")  
    public ModelAndView showform(){ 
		System.out.println("Hello");
        return new ModelAndView("empform","command",new EmpBean());  
    }
	
	/*@RequestMapping("/case2")  
    public ModelAndView showform1(){ 
        return new ModelAndView("case2");  
    }*/
	
	@RequestMapping("/case3")  
    public ModelAndView showform2(){ 
        return new ModelAndView("case3");  
    }
	
	@RequestMapping("/login")  
    public ModelAndView showform3(){ 
        return new ModelAndView("login");  
    }
	
	@RequestMapping("/payment")  
    public ModelAndView showform4(){ 
        return new ModelAndView("payment");  
    }
	
	@RequestMapping(value="/save",method = RequestMethod.POST)  
    public ModelAndView save(@ModelAttribute("emp") EmpBean emp){  
		int i=0;
        try {
        i=dao.save(emp);
        }catch (Exception e) {
        	return new ModelAndView("error");// TODO: handle exception
		}
       
        if(i > 0){
        	return new ModelAndView("viewemp");//will redirect to viewemp request mapping
        }else{
        	return new ModelAndView("error");
        }
    }
	
	@RequestMapping(value="/save1",method = RequestMethod.POST)  
    public ModelAndView save1(@ModelAttribute("emp") EmpBean emp){  
        
        int i=0;
        try {
        i=dao.save2(emp);
        }catch (Exception e) {
        	return new ModelAndView("error");// TODO: handle exception
		}
        if(i > 0){
        	return new ModelAndView("educational");//will redirect to viewemp request mapping
        }else{
        	return new ModelAndView("error");
        }
    }
	
	@RequestMapping(value="/cloud",method = RequestMethod.POST)  
    public ModelAndView cloud(@ModelAttribute("emp") CloudBean emp){  
		System.out.println("Hellohghgh");
		int i=0;
        try {
        i=dao.save1(emp);
        }catch (Exception e) {
        	return new ModelAndView("error");// TODO: handle exception
		}
	 
        if(i > 0){
        	System.out.println("hsahslfk");
        	return new ModelAndView("details");//will redirect to viewemp request mapping
        }else{
        	return new ModelAndView("error");
        }
    }
	
	@RequestMapping(value="/empdet",method = RequestMethod.POST)  
    public ModelAndView sloud(@ModelAttribute("emp") EmployeeBean emp){ 
		String email = Dao.email;
		if(email.equals(emp.getEmail())){
		 
			 int i=0;
		        try {
		        i=dao.store(emp); 
		        }catch (Exception e) {
		        	return new ModelAndView("error");// TODO: handle exception
				}
			if(i > 0){
				return new ModelAndView("cloud1");//will redirect to viewemp request mapping
			}else{
				dao.delete(email);
				return new ModelAndView("error");
			}
		}else{
			dao.delete(email);
			return new ModelAndView("error");
		}
    }
	
	@RequestMapping(value="/cloudid",method = RequestMethod.POST)  
    public ModelAndView cloudid(@ModelAttribute("emp") UserBean emp){  
        int i=0;
        try {
        i=dao.create(emp); 
        }catch (Exception e) {
        	return new ModelAndView("error");// TODO: handle exception
		}
        if(i > 0){
        	ModelAndView  mdv = new ModelAndView();
        	mdv.addObject("uid", emp.getEmail());
        	return new ModelAndView("payment");//will redirect to viewemp request mapping
        }else{
        	return new ModelAndView("error");
        }
    }
	
	@RequestMapping(value="/pay",method = RequestMethod.POST)  
    public ModelAndView pay(@ModelAttribute("emp") CardBean emp){  
        int i = 0;
        	if(emp.getCardno().equals("1232425262728292") && emp.getMon() == 9 && emp.getYear() == 22 && emp.getCvv() == 456){
        		i++;
        	}
        if(i > 0){
        	String sql = "insert into payment(userid, status1) values('"+emp.getUserid()+"','Completed')";
        	int j =dao.pay(sql);
        	if(j > 0){
        		return new ModelAndView("completed");
        	}else{
        		return new ModelAndView("error1");
        	}
        }else{
        	System.out.println("error");
        	return new ModelAndView("error1");
        }
	}
	
	@RequestMapping(value="/log",method = RequestMethod.POST)  
    public ModelAndView log(@ModelAttribute("emp") UserBean emp){  
        List<UserBean> lt = dao.getEmp();
        int i = 0;
        for(UserBean e: lt){
        	if(emp.getUserid().equals(e.getUserid()) && emp.getPassword().equals(e.getPassword())){
        		i++;
        	}
        }
        if(i > 0){
        	int j = 0;
        	List<PaymentBean> l1 = dao.getPay();
        	for(PaymentBean p : l1){
        		if(p.getUserid().equals(emp.getUserid())){
        			j++;
        		}
        	}
        	if(j > 0){
        		return new ModelAndView("ehome");
        	}else{
        		return new ModelAndView("ehome1");
        	}
    	}else{
    		return new ModelAndView("login");
    	}
	}
	
	@RequestMapping(value="/empdetails",method = RequestMethod.POST)  
    public ModelAndView empdetails(@ModelAttribute("emp") EmpDetailsBean emp){ 
		String empid = Dao.empid;
		if(empid.equals(emp.getEmpid())){
			int i = dao.store1(emp); 
			if(i > 0){
				return new ModelAndView("success");//will redirect to viewemp request mapping
			}else{
				dao.delete1(empid);
				return new ModelAndView("failed");
			}
		}else{
			dao.delete1(empid);
			return new ModelAndView("failed");
		}
    }
}
