package com.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;

import com.bean.CardBean;
import com.bean.CloudBean;
import com.bean.EmpBean;
import com.bean.EmpDetailsBean;
import com.bean.EmployeeBean;
import com.bean.PaymentBean;
import com.bean.UserBean;

public class Dao {

	JdbcTemplate template;  
	public static String empid;
	public static String email;
	public void setTemplate(JdbcTemplate template) {  
	    this.template = template;  
	}

	public int save(EmpBean emp) {
		// TODO Auto-generated method stub
		String sql="insert into employee(empname,email,password,empid) values('"+emp.getName()+"','"+emp.getEmail()+"','"+emp.getPassword()+"','"+emp.getEmpid()+"')";  
		return template.update(sql);
	}
	public int delete(String email1){  
	    String sql="delete from cloud where email='"+email1+"'";  
	    return template.update(sql);  
	}  
	
	public List<CardBean> getCards(){  
		System.out.println("kjkkls");
	    return template.query("select * from card",new RowMapper<CardBean>(){  
	        public CardBean mapRow(ResultSet rs, int row) throws SQLException { 
	        	System.out.println("Hello4585");
	            CardBean e=new CardBean();  
	            e.setCardno(rs.getString(1));
	            e.setMon(rs.getInt(2));
	            e.setYear(rs.getInt(3));
	            e.setCvv(rs.getInt(4));
	            return e;  
	        }  
	    });  
	}

	public int save1(CloudBean emp) {
		// TODO Auto-generated method stub
		System.out.println("ashfs");
		email = emp.getEmail();
		String sql="insert into cloud(email,cloud,space) values('"+email+"','"+emp.getCloud()+"','"+emp.getSpace()+"')";  
	    return template.update(sql);
	}

	public int store(EmployeeBean emp) {
		// TODO Auto-generated method stub
		String sql="insert into empdet(name,email,designation,experience) values('"+emp.getName()+"','"+emp.getEmail()+"','"+emp.getDesignation()+"',"+emp.getExperience()+")";  
	    return template.update(sql);
	}

	public int create(UserBean emp) {
		// TODO Auto-generated method stub
		String sql="insert into cloudid(email,userid,password) values('"+emp.getEmail()+"','"+emp.getUserid()+"','"+emp.getPassword()+"')";
	    return template.update(sql);
	}

	public int pay(String sql) {
		// TODO Auto-generated method stub
		return template.update(sql);
	}

	public List<UserBean> getEmp() {
		// TODO Auto-generated method stub
		return template.query("select * from cloudid",new RowMapper<UserBean>(){  
	        public UserBean mapRow(ResultSet rs, int row) throws SQLException {  
	            UserBean e=new UserBean();  
	            e.setEmail(rs.getString(1));
	            e.setUserid(rs.getString(2));
	            e.setPassword(rs.getString(3));
	            return e;  
	        }  
	    });
	}

	public List<PaymentBean> getPay() {
		// TODO Auto-generated method stub
		return template.query("select * from payment",new RowMapper<PaymentBean>(){  
	        public PaymentBean mapRow(ResultSet rs, int row) throws SQLException {  
	            PaymentBean e=new PaymentBean();  
	            e.setUserid(rs.getString(1));
	            return e;  
	        }  
	    });
	}
	
	public List<CardBean> getAllEmployees(){  
		 return template.query("select * from card",new ResultSetExtractor<List<CardBean>>(){  
		    @Override  
		     public List<CardBean> extractData(ResultSet rs) throws SQLException,  
		            DataAccessException {  
		      
		        List<CardBean> list=new ArrayList<CardBean>();  
		        while(rs.next()){  
		        	System.out.println("Hello4585");
		            CardBean e=new CardBean();  
		            e.setCardno(rs.getString(1));
		            e.setMon(rs.getInt(2));
		            e.setYear(rs.getInt(3));
		            e.setCvv(rs.getInt(4));  
		        list.add(e);  
		        }  
		        return list;  
		        }  
		    });  
		  }


	public int save2(EmpBean emp) {
		// TODO Auto-generated method stub
		empid = emp.getEmpid();
		String sql="insert into employee(empname,email,password,empid) values('"+emp.getName()+"','"+emp.getEmail()+"','"+emp.getPassword()+"','"+empid+"')";  
		return template.update(sql);
	}

	public int store1(EmpDetailsBean emp) {
		// TODO Auto-generated method stub
		String sql="insert into empdetails(empid,designation,experience,salary,marital) values('"+emp.getEmpid()+"','"+emp.getDesignation()+"',"+emp.getExperience()+","+emp.getSalary()+",'"+emp.getMarital()+"')";  
		return template.update(sql);
	}

	public int delete1(String empid2) {
		// TODO Auto-generated method stub
		String sql="delete from employee where empid='"+empid2+"'";  
	    return template.update(sql); 
	}

}
	
